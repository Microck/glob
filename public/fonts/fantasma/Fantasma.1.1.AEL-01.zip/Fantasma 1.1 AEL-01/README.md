# Fantasma
Fantasma: An「ael-lab」Release AEL-01 // Font design by Froyo Tam
AEL-01

Font design by Froyo Tam // Posters by Articution, Boocanan, Froyo Tam, Ghost.Snacks, Integra, om_neb (more to be announced)

![Image](https://raw.githubusercontent.com/froyotam/fantasma/main/documentation/fantasmaspecimen_indexedcolor.png?token=AOBDNVIZEUAA2FFRKYQ5YP3BCNXHY)
//Posters by Arte Et Labore
Poster Prompt: Evoke the feeling of a metaphorical “phantom”.
// Poster by Articution 
![Image](https://raw.githubusercontent.com/froyotam/fantasma/main/documentation/fantasma-poster-arti.png?token=AOBDNVIKWL2HNTYVYSTBUZDBCNWWA)
// Poster by Boocanan
![Image](https://raw.githubusercontent.com/froyotam/fantasma/main/documentation/BoocananFantasmaPosterCMYK300dpi.png?token=AOBDNVMN4322WWPYYTP4YBDBCNWX4)
// Poster by Froyo Tam
![Image](https://raw.githubusercontent.com/froyotam/fantasma/main/documentation/vanishingmetadata_indexed.png?token=AOBDNVMT7IYKWRHVRG7DLJTBCNW2G)
// Poster by Ghost.Snacks
![Image](https://raw.githubusercontent.com/froyotam/fantasma/main/documentation/110821_ghostsnacks.jpeg?token=AOBDNVPA3HLXGTDJDZ3XGMDBCNW6I)
// Poster by Integra
![Image](https://raw.githubusercontent.com/froyotam/fantasma/main/documentation/ArteLabore_Fantasma_Poster_Integra_Print_3.jpeg?token=AOBDNVID4Q7FETJLYA3MM7LBCNXBE)
// Poster by om.neb
![Image](https://raw.githubusercontent.com/froyotam/fantasma/main/documentation/Apparition_FantasmaPoster_Fixed.png?token=AOBDNVK7V3PTNAUQKUYLO73BCNXDQ)

Font licensed under GNU General Public License 3.0
